Track "Avatar" made by Altzeus for use in this mod.
Track "Sonar" from CE